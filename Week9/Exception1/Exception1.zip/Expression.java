public abstract class Expression {
    @Override
    public abstract String toString();

    abstract double evaluate();
}