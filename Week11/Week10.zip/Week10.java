import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Week10 {

    public static List<String> getAllFunctions(String fileContent) {
        List<String> functions = new ArrayList<>();

        // Step 1: Remove comments
        String processedContent = fileContent.replaceAll("(?s)/\\*.*?\\*/", "");
        processedContent = processedContent.replaceAll("//.*", "");

        // Step 2: Extract package and imports
        String packageName = "";
        List<String> singleImports = new ArrayList<>();
        List<String> wildcardImports = new ArrayList<>();

        Matcher packageMatcher = Pattern.compile("\\bpackage\\s+([^;]+);").matcher(processedContent);
        if (packageMatcher.find()) {
            packageName = packageMatcher.group(1).trim();
        }

        Matcher importMatcher = Pattern.compile("\\bimport\\s+(static\\s+)?([^;]+);").matcher(processedContent);
        while (importMatcher.find()) {
            boolean isStatic = importMatcher.group(1) != null;
            String importStr = importMatcher.group(2).trim();
            if (isStatic) continue;
            if (importStr.endsWith(".*")) {
                wildcardImports.add(importStr.substring(0, importStr.length() - 2));
            } else {
                singleImports.add(importStr);
            }
        }

        // Add java.lang to wildcard imports implicitly
        if (!wildcardImports.contains("java.lang")) {
            wildcardImports.add("java.lang");
        }

        // Step 3: Normalize whitespace and handle generics
        processedContent = processedContent.replaceAll("\\s+", " ");
        processedContent = processedContent.replaceAll("<\\s+", "<");
        processedContent = processedContent.replaceAll("\\s+>", ">");

        // Step 4: Find static method declarations with improved regex
        Pattern methodPattern = Pattern.compile(
                "\\bstatic\\s+((?:\\w+|<[^>]+>|\\[\\])+?)\\s+(\\w+)\\s*\\(");
        Matcher methodMatcher = methodPattern.matcher(processedContent);

        while (methodMatcher.find()) {
            String methodName = methodMatcher.group(2);
            String paramsStr = extractParameters(processedContent, methodMatcher.end());

            List<String> paramTypes = new ArrayList<>();
            if (!paramsStr.isEmpty()) {
                String[] params = paramsStr.split("\\s*,\\s*");
                for (String param : params) {
                    String type = extractParameterType(param);
                    String resolvedType = resolveFullType(type, singleImports, wildcardImports, packageName);
                    paramTypes.add(resolvedType);
                }
            }

            functions.add(methodName + "(" + String.join(",", paramTypes) + ")");
        }

        return functions;
    }

    private static String extractParameters(String content, int start) {
        int level = 1;
        StringBuilder params = new StringBuilder();
        for (int i = start; i < content.length(); i++) {
            char c = content.charAt(i);
            if (c == '(') level++;
            if (c == ')') level--;
            if (level == 0) break;
            if (level == 1 && c != '(') params.append(c);
        }
        return params.toString().trim();
    }

    private static String extractParameterType(String param) {
        param = param.replaceAll("\\s*final\\s*", "")
                    .replaceAll("\\s*...\\s*", "")
                    .trim();

        // Split parameter into type and name
        String[] parts = param.split("\\s+(?![^<]*>)");
        if (parts.length < 2) return param;
        
        StringBuilder typeBuilder = new StringBuilder();
        for (int i = 0; i < parts.length - 1; i++) {
            typeBuilder.append(parts[i]).append(" ");
        }
        return typeBuilder.toString().trim();
    }

    private static String resolveFullType(String type, List<String> singleImports, 
                                        List<String> wildcardImports, String packageName) {
        // Handle generic types and arrays
        if (type.contains("<") || type.contains("[")) {
            return resolveComplexType(type, singleImports, wildcardImports, packageName);
        }
        return resolveSimpleType(type, singleImports, wildcardImports, packageName);
    }

    private static String resolveComplexType(String type, List<String> singleImports,
                                            List<String> wildcardImports, String packageName) {
        // Process generic parameters
        StringBuilder result = new StringBuilder();
        int lastIndex = 0;
        int bracketLevel = 0;

        for (int i = 0; i < type.length(); i++) {
            char c = type.charAt(i);
            if (c == '<' || c == '[') bracketLevel++;
            if (c == '>' || c == ']') bracketLevel--;

            if ((c == ',' || c == '<' || c == '>' || c == '[' || c == ']') && bracketLevel <= 1) {
                String segment = type.substring(lastIndex, i).trim();
                if (!segment.isEmpty()) {
                    String resolved = resolveSimpleType(segment, singleImports, wildcardImports, packageName);
                    result.append(resolved);
                }
                result.append(c);
                lastIndex = i + 1;
            }
        }

        // Add remaining segment
        String lastSegment = type.substring(lastIndex).trim();
        if (!lastSegment.isEmpty()) {
            String resolved = resolveSimpleType(lastSegment, singleImports, wildcardImports, packageName);
            result.append(resolved);
        }

        return result.toString();
    }

    private static String resolveSimpleType(String type, List<String> singleImports,
                                           List<String> wildcardImports, String packageName) {
        if (type.matches("[A-Z]")) return type; // Type parameter
        if (type.contains(".")) return type; // Already FQN

        // Check single imports
        for (String imp : singleImports) {
            if (imp.endsWith("." + type)) return imp;
        }

        // Check package
        if (!packageName.isEmpty()) {
            String fqn = packageName + "." + type;
            return fqn;
        }

        // Check wildcard imports
        for (String wildcard : wildcardImports) {
            String fqn = wildcard + "." + type;
            return fqn;
        }

        return "java.lang." + type;
    }
}