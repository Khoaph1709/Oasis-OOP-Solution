import java.util.ArrayList;
import java.util.List;

public class Layer {
    private ArrayList<Shape> shapes;
    private int count = 0;

    public void addShape(Shape shape) {
        shapes.add(shape);
    }

    public void removeCircles() {
        for (int i = 0; i < shapes.size(); i++) {
            if (shapes.get(i) instanceof Circle) {
                shapes.remove(i);
                i--;
            }
        }
    }

    public String getInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("Layer of crazy shapes:\n\n");
        for (Shape shape : shapes) {
            sb.append(shape).append("\n");
        }

        return sb.toString();
    }

    public void removeDuplicates() {
        for (int i = 0; i < shapes.size() - 1; i++) {
            for (int j = i + 1; j < shapes.size(); j++) {
                if (shapes.get(i).equals(shapes.get(j))) {
                    shapes.remove(j);
                    j--;
                }
            }
        }
    }
}
